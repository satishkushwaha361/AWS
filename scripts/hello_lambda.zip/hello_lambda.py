# Does NOT implement the PEP 249 spec, but the return type is suggested by the .fetchall function as specified here: https://www.python.org/dev/peps/pep-0249/#fetchall

import time
import boto3

query_string='SELECT * FROM water'
client=boto3.client('athena')

def lambda_handler(event, context):
    client=boto3.client('athena')

    #setup and perform query
    query_id=client.start_query_execution(
        QueryString = 'SELECT * FROM water limit 10',
        QueryExecutionContext = {
            'Database':'mydatabase'
        },
        ResultConfiguration = {
            'OutputLocation': 's3://satishathenabucketoutput/output/'
        }
    #)  
    )['QueryExecutionId'] 
    query_status = None
    while query_status == 'QUEUED' or query_status == 'RUNNING' or query_status is None:
        query_status = client.get_query_execution(QueryExecutionId=query_id)['QueryExecution']['Status']['State']
        if query_status == 'FAILED' or query_status == 'CANCELLED':
            raise Exception('Athena query with the string "{}" failed or was cancelled'.format(query_string))
        time.sleep(10)
    results_paginator = client.get_paginator('get_query_results')
    results_iter = results_paginator.paginate(
        QueryExecutionId=query_id,
        PaginationConfig={
            'PageSize': 1000
        }
    )
    results = []
    for x in results:
        print(x, end=' ')
    data_list = []
    for results_page in results_iter:
        for row in results_page['ResultSet']['Rows']:
            #print(row)
            data_list.append(row['Data'])
    for datum in data_list[1:]:
        #results.append([x['VarCharValue'] for x in datum])
        results.append([x['VarCharValue'] if 'VarCharValue' in x else '' for x in datum])
    #return [tuple(x) for x in results]
    return results
